<?php

if (!defined('APP_ROOT')) {
    $documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');
    $projectRoot = realpath(__DIR__ . '/..');
    $relativeRoot = ($documentRoot && $projectRoot && str_starts_with(strtolower($projectRoot), strtolower($documentRoot)))
        ? substr($projectRoot, strlen($documentRoot))
        : '/' . basename(dirname(__DIR__));
    $normalizedRoot = trim(str_replace('\\', '/', $relativeRoot), '/');
    define('APP_ROOT', $normalizedRoot === '' ? '' : '/' . $normalizedRoot);
}

function db(): mysqli
{
    static $connection = null;

    if ($connection instanceof mysqli) {
        return $connection;
    }

    $host = getenv('ECOLOOP_DB_HOST') ?: 'localhost';
    $username = getenv('ECOLOOP_DB_USER') ?: 'root';
    $password = getenv('ECOLOOP_DB_PASSWORD') ?: '';
    $database = getenv('ECOLOOP_DB_NAME') ?: 'eco_loop_db';

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    try {
        $connection = new mysqli($host, $username, $password, $database);
        $connection->set_charset('utf8mb4');
        return $connection;
    } catch (mysqli_sql_exception $e) {
        $message = 'Database connection failed. Please import the database schema and ensure MySQL is running in XAMPP.';
        throw new RuntimeException($message, 0, $e);
    }
}

function db_configured(): bool
{
    try {
        db()->ping();
        return true;
    } catch (Throwable $e) {
        return false;
    }
}
